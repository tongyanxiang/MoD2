#!/bin/bash
MAINSIMDIR=../src/
MAINSIMEXEC=swim

$MAINSIMDIR/$MAINSIMEXEC -m -u Cmdenv -c General -n .:$MAINSIMDIR:../../queueinglib -l ../../queueinglib/queueinglib swim.ini
