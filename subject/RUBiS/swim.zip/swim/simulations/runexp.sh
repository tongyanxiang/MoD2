cd /home/tong/omnetpp-5.5.1/samples/swim/simulations
../src/swim_dbg -m -u Cmdenv -n .:../src:../../queueinglib -l ../../queueinglib/queueinglib swim.ini
