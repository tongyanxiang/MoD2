//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __SWIM_MOD2_H_
#define __SWIM_MOD2_H_

#include <omnetpp.h>
#include <managers/monitor/SimpleMonitor.h>
#include <managers/plan/OptimalController.h>
#include <supervision/Switcher.h>

using namespace omnetpp;

/**
 * Model-guided model Deviation Detector
 */
class MoD2 : public cSimpleModule
{
  public:
    SimpleMonitor *pMonitor;
    OptimalController *pCtrl;
    Switcher *pSwitcher;

    int num=0;
    int controlServers;
    double measuredArrivalRate;
    double measuredAvgRespTime;

    // system state
    double deltaState[2][1] = {{0.0}, {0.0}};
    double deltaStateVar[2][2] = {{0.0, 0.0}, {0.0, 0.0}};

    // deviated model parameter
    double B_k[2][1] = {{1.0}, {0.0}};
    double P_k[2][2] = {{0.001, 0.0}, {0.0, 0.0}};

    // historical measurements
    std::vector<int> list_u = {};
    std::vector<double> list_a = {};
    std::vector<double> list_y = {};

    // alarm signal
    int alarm = 0;

    void deviationDetector(int controlServers, double measuredArrivalRate, double measuredAvgRespTime);
    void transferDetectionData();
    void updateDetector();
    void writeRes();
    std::vector<double> split(std::string str);

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
