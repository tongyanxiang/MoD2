//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <iostream>
#include <fstream>
#include <boost/tokenizer.hpp>
#include "MoD2.h"

Define_Module(MoD2);

void MoD2::initialize() {
    pMonitor = check_and_cast<SimpleMonitor*> (getParentModule()->getSubmodule("monitor"));
    pCtrl = check_and_cast<OptimalController*> (getParentModule()->getSubmodule("optimalController"));
    pSwitcher = check_and_cast<Switcher*> (getParentModule()->getSubmodule("switcher"));

    // delete old detection result file
    ifstream cpFin("../result/RUBiSRes.txt");
    if (!cpFin) {
        cout << "t=" << simTime() << " [MoD2] RUBiSRes.txt does not exist" << endl;
    } else {
        remove("../result/RUBiSRes.txt");
        cout << "t=" << simTime() << " [MoD2] Delete RUBiSRes.txt" << endl;
    }

    ofstream out;
    out.open("../result/RUBiSRes.txt", ios::app);
    if (out.is_open()) {
        out << "u_{k-1}, a_k, y_k, B_k, P_k, alarm \n";
        out.close();
    }
}

void MoD2::handleMessage(cMessage *msg) {

    controlServers = pCtrl->getControlServers();
    measuredArrivalRate =  pMonitor->getMeasuredArrivalRate();
    measuredAvgRespTime = pMonitor->getMeasuredAvgRespTime();

    cout << "t=" << simTime() << " [MoD2]"
                              << " controlServers[" << num << "]="      << controlServers
                              << " measuredArrivalRate[" << num << "]=" << measuredArrivalRate
                              << " measuredAvgRespTime[" << num << "]=" << measuredAvgRespTime << endl;

    bool triggerMandatoryCtrl = pSwitcher->getSwitcherMode();
    if (not triggerMandatoryCtrl) {
        deviationDetector(controlServers, measuredArrivalRate, measuredAvgRespTime);
    }

    send(msg, "out");
}

void MoD2::deviationDetector(int controlServers, double measuredArrivalRate, double measuredAvgRespTime){

    if (list_u.size()<4){
        list_u.push_back(controlServers);
        list_a.push_back(measuredArrivalRate);
        list_y.push_back(measuredAvgRespTime);

    } else {
        list_u.push_back(controlServers);
        list_a.push_back(measuredArrivalRate);
        list_y.push_back(measuredAvgRespTime);

        // transfer data to MoD2.py
        transferDetectionData();

        // get data form MoD2.py
        int status = system("python3 ../src/supervision/MoD2.py");
        updateDetector();

        // set switcher
        if (alarm==1){
            pSwitcher->setSwitcherMode(true);
        }

        // save detection information
        writeRes();

        // update old data
        vector<int>::iterator k1 = list_u.begin();
        list_u.erase(k1);

        vector<double>::iterator k2 = list_a.begin();
        list_a.erase(k2);

        vector<double>::iterator k3 = list_y.begin();
        list_y.erase(k3);
    }

    num = num + 1;
}

void MoD2::transferDetectionData() {
    ofstream out;
    out.open("../src/supervision/detectionData/oldDetectionData.txt", ios::out);
    if (out.is_open()) {
        //state mean and variance
        out << deltaState[0][0];
        out << ",";
        out << deltaState[1][0];
        out << "\n";
        out << deltaStateVar[0][0];
        out << ",";
        out << deltaStateVar[0][1];
        out << ",";
        out << deltaStateVar[1][0];
        out << ",";
        out << deltaStateVar[1][1];
        out << "\n";

        //parameter mean and variance
        out << B_k[0][0];
        out << ",";
        out << B_k[1][0];
        out << "\n";
        out << P_k[0][0];
        out << ",";
        out << P_k[0][1];
        out << ",";
        out << P_k[1][0];
        out << ",";
        out << P_k[1][1];
        out << "\n";

        // horizon list
        for(unsigned int i = 0; i < list_u.size()-1; i++) {
            out << list_u[i];
            out << ",";
        }
        out << list_u[list_u.size()-1];
        out << "\n";

        for(unsigned int i = 0; i < list_a.size()-1; i++) {
            out << list_a[i];
            out << ",";
        }
        out << list_a[list_a.size()-1];
        out << "\n";

        for(unsigned int i = 0; i < list_y.size()-1; i++) {
            out << list_y[i];
            out << ",";
        }
        out << list_y[list_y.size()-1];
        out << "\n";
    }
    out.close();
}

void MoD2::updateDetector() {
    fstream infile("../src/supervision/detectionData/newDetectionData.txt");

    if (infile.is_open()) {
        std::string line;

        std::getline(infile, line);
        std::vector<double> newDeltaState = split(line);
        deltaState[0][0] = newDeltaState[0];
        deltaState[1][0] = newDeltaState[1];

        std::getline(infile, line);
        std::vector<double> newDeltaStateVar = split(line);
        deltaStateVar[0][0] = newDeltaStateVar[0];
        deltaStateVar[0][1] = newDeltaStateVar[1];
        deltaStateVar[1][0] = newDeltaStateVar[2];
        deltaStateVar[1][1] = newDeltaStateVar[3];

        std::getline(infile, line);
        std::vector<double> newB_k = split(line);
        B_k[0][0] = newB_k[0];
        B_k[1][0] = newB_k[1];

        std::getline(infile, line);
        std::vector<double> newP = split(line);
        P_k[0][0] = newP[0];
        P_k[0][1] = newP[1];
        P_k[1][0] = newP[2];
        P_k[1][1] = newP[3];

        std::getline(infile, line);
        alarm = atoi(line.c_str());

        cout << "t=" << simTime() << " [MoD2] B_k=" << B_k[0][0] << " P_k=" << P_k[0][0] << " alarm=" << alarm << endl;
    }

    infile.close();
}

void MoD2::writeRes() {

    ofstream out;
    out.open("../result/RUBiSRes.txt", ios::app);
    if (out.is_open()) {
        out << controlServers;
        out << ", ";
        out << measuredArrivalRate;
        out << ", ";
        out << measuredAvgRespTime;
        out << ", ";
        out << B_k[0][0];
        out << ", ";
        out << P_k[0][0];
        out << ", ";
        out << alarm;
        out << "\n";
        out.close();
    }
}

std::vector<double> MoD2::split(std::string str) {
    std::vector<double> results;
    typedef boost::tokenizer<boost::char_separator<char> > tokenizer;
    tokenizer tokens(str, boost::char_separator<char>(","));
    tokenizer::iterator it = tokens.begin();

    if (it != tokens.end()) {
        string command = *it;
        while (it != tokens.end()) {
            results.push_back(atof((*it).c_str()));
            it++;
        }
    }

    return results;
}



