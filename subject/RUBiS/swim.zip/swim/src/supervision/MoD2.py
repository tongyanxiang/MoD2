import os
import numpy as np
from scipy import stats

class MoD2:
    # Model-guided model Deviation Detector

    def __init__(self):

        # Nominal model parameters
        self.A = np.array([[0.0, 0.0],
                           [1.0, 0.0]])

        self.B = np.array([[1.0],
                           [0.0]])

        self.C = np.array([[0.0, -0.076]])

        # Deviated model parameter
        self.B_k = self.B
        self.P_k = np.array([[0.001, 0.0],
                             [0.0,   0.0]])

        # System state
        self.deltaState = np.zeros((2,1))
        self.deltaStateVar = np.zeros((2,2))

        # Uncertainty of model parameter value
        self.Q = np.array([[0.0008, 0.0],
                           [0.0,   0.0]])    # estimate uncertainty

        # Uncertainty compensation terms
        self.gamma = np.array([[0.0],
                               [0.02930]])
        self.W = np.array([[0.0, 0.0],
                           [0.0, 0.006891]])  # measurement error of environment input
        self.V = np.array([[2.0e-06]])        # sensor noise

        # Safe region
        self.pole = 0.9
        self.safeRegion = [0.0, 1.0/(4.0*(1-self.pole))*self.B[0][0]]

        # Probability threshold
        self.probThreshold = 0.9973  # 3sigma

        # Alarm signal
        self.alarm = 0

        # Historical measurements
        self.list_u = []  # historical output of the controller
        self.list_a = []  # historical environmental input
        self.list_y = []  # historical managed system’s output

    def deviationDetector(self, deltaState, deltaStateVar, B_k, P_k, list_u, list_a, list_y):

        # State estimation
        delta_y_3 = list_y[1] - list_y[0]
        delta_u_3 = list_u[2] - list_u[1]
        delta_a_2 = list_a[2] - list_a[1]

        deltaState, deltaStateVar = self.observer(B_k, deltaState, deltaStateVar,
                                                  delta_y_3, delta_u_3, delta_a_2)

        # Model parameter estimation and deviation detection
        delta_u_2 = list_u[3] - list_u[2]

        if abs(delta_u_2)>0:
            delta_a_1 = list_a[3] - list_a[2]
            delta_a_0 = list_a[4] - list_a[3]
            delta_y_0 = list_y[4] - list_y[3]

            B_k, P_k = self.estimator(deltaState, deltaStateVar, B_k, P_k,
                                      delta_u_2, delta_a_1, delta_a_0, delta_y_0)
            self.alarm = self.passiveDetector(B_k, P_k)

        else:
            setpoint = 0.3
            delta = list_y[4] - setpoint
            self.alarm = self.activeDetector(delta)

        return deltaState, deltaStateVar, B_k, P_k, self.alarm

    def observer(self, B_k, deltaState, deltaStateVar, delta_y_3, delta_u_3, delta_a_2):

        # Update process
        ## innovation variance
        R_k = np.dot(np.dot(self.C,deltaStateVar),self.C.T) + self.V

        ## updated Kalman gain
        K = np.dot(np.dot(deltaStateVar,self.C.T),np.linalg.inv(R_k))

        ## updated (a posteriori) state estimate
        error = delta_y_3 - np.dot(self.C,deltaState)
        deltaState = deltaState + np.dot(K,error)

        ## updated (a posteriori) state estimate variance
        deltaStateVar = np.dot((np.eye(len(deltaStateVar))-np.dot(K,self.C)),deltaStateVar)

        # Prediction process
        ## predicted (a priori) state estimate
        deltaState = np.dot(self.A,deltaState) + np.dot(B_k,delta_u_3) + np.dot(self.gamma,delta_a_2)

        ## predicted (a priori) state estimate variance
        deltaStateVar = np.dot(np.dot(self.A,deltaStateVar),self.A.T) + self.W

        return deltaState, deltaStateVar

    def estimator(self, deltaState, deltaStateVar, B_k, P_k,
                        delta_u_2, delta_a_1, delta_a_0, delta_y_0):

        # Prediction process
        ## predicted (a priori) model parameter estimate
        B_k = B_k

        ## predicted (a priori) model parameter estimate variance
        P_k = P_k + self.Q

        # Update process
        ## innovation variance
        H = np.dot(np.dot(self.C,self.A),delta_u_2)
        Matrix = np.dot(self.C,np.dot(self.A,self.A))
        R_k = np.dot(np.dot(Matrix,deltaStateVar),Matrix.T) + np.dot(np.dot(H,P_k),H.T) + \
              np.dot(np.dot(np.dot(self.C,self.A),self.W),np.dot(self.C,self.A).T) + np.dot(np.dot(self.C,self.W),self.C.T) + self.V

        ## updated Kalman gain
        K = np.dot(np.dot(P_k,H.T),np.linalg.inv(R_k))

        ## updated (a posteriori) model parameter estimate
        error = delta_y_0-(np.dot(np.dot(np.dot(self.C,self.A),self.A),deltaState) + np.dot(H,B_k) +
                           np.dot(np.dot(np.dot(self.C,self.A),self.gamma),delta_a_1) + np.dot(np.dot(self.C,self.gamma),delta_a_0))
        B_k = B_k + np.dot(K,error)

        ## updated (a posteriori) model parameter estimate variance
        P_k = np.dot((np.eye(len(P_k))-np.dot(K,H)),P_k)

        return B_k, P_k

    def passiveDetector(self, B_k, P_k):

        # Alarm if the derived probability that model parameter value
        # falls into safe region exceeds the probability threshold

        loc = B_k[0][0]
        scale = np.sqrt(P_k[0][0])
        cdf = stats.norm.cdf(self.safeRegion[1], loc, scale) - stats.norm.cdf(self.safeRegion[0], loc, scale)

        passive_alarm = 0
        if cdf < self.probThreshold:
            passive_alarm = 1

        return passive_alarm

    def activeDetector(self, delta):

        # Alarm if derived probability of occuring delta value of
        # the managed system's ouput is less tha probability threshold

        loc = 0.0
        scale = 0.1699
        prob6sigma = 0.999999981

        if delta <= loc:
            cdf = stats.norm.cdf(delta, loc, scale)
        else:
            cdf = 1.0 - stats.norm.cdf(delta, loc, scale)

        active_alarm = 0
        if cdf < 1.0 - prob6sigma:
            active_alarm = 1

        return active_alarm

def LoadDetectorTempData():

    # initialization
    deltaState = np.zeros((2,1))
    deltaStateVar = np.zeros((2,2))
    B_k = np.zeros((2,1))
    P_k = np.zeros((2,2))
    list_u = []
    list_a = []
    list_y = []

    # load old temp data
    oldTempFilePath = "../src/supervision/detectionData/oldDetectionData.txt"
    fr = open(oldTempFilePath)
    lines = fr.readlines()
    fr.close()

    res = lines[0].strip().split(",")
    deltaState[0][0] = float(res[0])
    deltaState[1][0] = float(res[1])

    res = lines[1].strip().split(",")
    deltaStateVar[0][0] = float(res[0])
    deltaStateVar[0][1] = float(res[1])
    deltaStateVar[1][0] = float(res[2])
    deltaStateVar[1][1] = float(res[3])

    res = lines[2].strip().split(",")
    B_k[0][0] = float(res[0])
    B_k[1][0] = float(res[1])

    res = lines[3].strip().split(",")
    P_k[0][0] = float(res[0])
    P_k[0][1] = float(res[1])
    P_k[1][0] = float(res[2])
    P_k[1][1] = float(res[3])

    res = lines[4].strip().split(",")
    for i in range(0, len(res)):
        list_u.append(int(res[i]))

    res = lines[5].strip().split(",")
    for i in range(0, len(res)):
        list_a.append(float(res[i]))

    res = lines[6].strip().split(",")
    for i in range(0, len(res)):
        list_y.append(float(res[i]))

    os.remove(oldTempFilePath)

    return deltaState, deltaStateVar, B_k, P_k, list_u, list_a, list_y

def saveUpdateDetectorTempData(deltaState, deltaStateVar, B_k, P_k, alarm):
    # save temp data
    newTempFilePath = "../src/supervision/detectionData/newDetectionData.txt"
    fw = open(newTempFilePath, "w+")

    fw.write(str(deltaState[0][0]) + "," + str(deltaState[1][0]) + "\n")
    fw.write(str(deltaStateVar[0][0]) + "," + str(deltaStateVar[0][1]) + "," + str(deltaStateVar[1][0]) + "," + str(deltaStateVar[1][1])  + "\n")
    fw.write(str(B_k[0][0]) + "," + str(B_k[1][0]) + "\n")
    fw.write(str(P_k[0][0]) + "," + str(P_k[0][1]) + "," + str(P_k[1][0]) + "," + str(P_k[1][1])  + "\n")
    fw.write(str(alarm) + "\n")
    fw.flush()
    fw.close()


if __name__ == "__main__":

    # initialize detector
    detector = MoD2()

    # load temp data
    deltaState, deltaStateVar, B_k, P_k, list_u, list_a, list_y = LoadDetectorTempData()

    # detection
    deltaState, deltaStateVar, \
    B_k, P_k, alarm = detector.deviationDetector(deltaState, deltaStateVar, B_k, P_k,
                                                 list_u, list_a, list_y)

    saveUpdateDetectorTempData(deltaState, deltaStateVar, B_k, P_k, alarm)
