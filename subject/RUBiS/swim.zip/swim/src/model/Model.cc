/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <sstream>
#include <math.h>
#include <assert.h>
#include "util/Utils.h"
#include "managers/execution/ExecutionManagerModBase.h"
#include "Model.h"

using namespace omnetpp;

Define_Module(Model);

void Model::addExpectedServerChange(double time, ModelServerChange change) {
    ModelServerChangeEvent event;
    event.startTime = simTime().dbl();
    event.time = time;
    event.change = change;
    serverChangeEvents.insert(event);
}

void Model::addServer(double bootDelay) {
    addExpectedServerChange(simTime().dbl() + bootDelay, Model::SERVER_ONLINE);

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [Model] addServer bootDelay=" << bootDelay
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void Model::removeServer(double bootDelay) {
    addExpectedServerChange(simTime().dbl() + bootDelay, Model::SERVER_OFFLINE);

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [Model] removeServer bootDelay=" << bootDelay
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void Model::serverBecameActive() {
    /* remove expected change...*/
    ModelServerChangeEvents::iterator it = serverChangeEvents.begin();
    while (it != serverChangeEvents.end() && it->change != Model::SERVER_ONLINE) {
        it++;
    }

    assert(it != serverChangeEvents.end()); // there must be an expected server boot change for this
    serverChangeEvents.erase(it);

    activeServers++;

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [Model] serverBecameActive"
                                  << " serverCount=" << getServers()
                                  << " active="      << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="    << serverChangeEvents.size() << endl;
    }
}

void Model::serverBecameShutDown() {
    /* remove expected change...*/
    ModelServerChangeEvents::iterator it = serverChangeEvents.begin();
    while (it != serverChangeEvents.end() && it->change != Model::SERVER_OFFLINE) {
        it++;
    }

    assert(it != serverChangeEvents.end()); // there must be an expected server shutdown change for this
    serverChangeEvents.erase(it);

    activeServers--;

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [Model] serverBecameShutDown"
                                  << " serverCount=" << getServers()
                                  << " active="      << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="    << serverChangeEvents.size() << endl;
    }
}

int Model::numServerBooting() const {
    int bootingNum = 0;

    if (!serverChangeEvents.empty()){
        /* find the number of booting servers */
        ModelServerChangeEvents::const_iterator eventIt = serverChangeEvents.begin();
        while(eventIt != serverChangeEvents.end()) {
            if(eventIt->change == SERVER_ONLINE){
                bootingNum++;
            }
            eventIt++;
        }
   }
    return bootingNum;
}

int Model::numServerShutting() const {
    int shuttingNum = 0;

    if (!serverChangeEvents.empty()){
        /* find the number of booting servers */
        ModelServerChangeEvents::const_iterator eventIt = serverChangeEvents.begin();
        while(eventIt != serverChangeEvents.end()) {
            if(eventIt->change == SERVER_OFFLINE){
                shuttingNum++;
            }
            eventIt++;
        }
   }
    return shuttingNum;
}

void Model::pushServerPool(double time, int id) {
    cout << "push id=" << id << " time=" << time << endl;
    ModelServerPoolEvent event;
    event.time = time;
    event.id = id;
    serverPoolEvents.insert(event);
}

int Model::popServerPool() {
    int id = -1;
    if (!serverPoolEvents.empty()) {
        ModelServerPoolEvents::iterator it = serverPoolEvents.end();
        it--;
        id = it->id;
        serverPoolEvents.erase(it);
    }
    cout << "pop id=" << id << " time=" << simTime().dbl() << endl;
    return id;
}

std::vector<int> Model::getServerPool() {
    serverModuleIds.clear();
    ModelServerPoolEvents::iterator it = serverPoolEvents.begin();
    while (it != serverPoolEvents.end()) {
        serverModuleIds.push_back(it->id);
        it++;
    }
    return serverModuleIds;
}

void Model::initialize(int stage) {
    if (stage == 0) {
        cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging");

        // server config
        brownoutFactor = getSimulation()->getSystemModule()->par("brownoutFactor");
        maxServers = getSimulation()->getSystemModule()->par("maxServers");

        // uncertainty
        bootDelay = Utils::getMeanAndVarianceFromParameter(getSimulation()->getSystemModule()->par("bootDelay"));
        offDelay = Utils::getMeanAndVarianceFromParameter(getSimulation()->getSystemModule()->par("offDelay"));

        controlPeriod = getSimulation()->getSystemModule()->par("controlPeriod").doubleValue();

        warmTimeSteps = getSimulation()->getSystemModule()->par("warmTimeSteps");;

        cout << "t=" << simTime() << " [Model] initialize server"
                                  << " brownoutFactor="        << brownoutFactor
                                  << " maxServers="            << maxServers << endl;

        cout << "t=" << simTime() << " [Model] initialize uncertainty"
                                  << " bootDelay="             << bootDelay  << endl;

        cout << "t=" << simTime() << " [Model] initialize control loop"
                                  << " controlPeriod="           << controlPeriod
                                  << " warmTimeSteps="           << warmTimeSteps  << endl;
    } else {
        // start servers
        ExecutionManagerModBase* pExecMgr = check_and_cast<ExecutionManagerModBase*> (getParentModule()->getSubmodule("executionManager"));

        int initialServers = getSimulation()->getSystemModule()->par("initialServers");

        cout << "t=" << simTime() << " [Model] initialServers=" << initialServers << endl;

        while (initialServers > 0) {
            pExecMgr->addServerLatencyOptional(true); // add a server instantaneously
            initialServers--;
        }
    }
}

// server config
double Model::getBrownoutFactor() const {
    return brownoutFactor;
}

void Model::setBrownoutFactor(double factor) {
    brownoutFactor = factor;
}

int Model::getMaxServers() const {
    return maxServers;
}

int const Model::getServers() const {
    return activeServers + numServerBooting()-numServerShutting();
}

int const Model::getActiveServers() const {
    return activeServers;
}

int Model::getServerThreads() const {
    return serverThreads;
}

void Model::setServerThreads(int serverThreads) {
    this->serverThreads = serverThreads;
}

double Model::getServiceTimeMean() const {
    return serviceTimeMean;
}

void Model::setServiceTime(double serviceTimeMean, double serviceTimeVariance) {
    this->serviceTimeMean = serviceTimeMean;
    this->serviceTimeVariance = serviceTimeVariance;
}

double Model::getLowFidelityServiceTimeMean() const {
    return lowFidelityServiceTimeMean;
}

void Model::setLowFidelityServiceTime(double lowFidelityServiceTimeMean, double lowFidelityServiceTimeVariance) {
    this->lowFidelityServiceTimeMean = lowFidelityServiceTimeMean;
    this->lowFidelityServiceTimeVariance = lowFidelityServiceTimeVariance;
}

// uncertainty
double Model::getBootDelay() const {
    return bootDelay;
}

// control
double Model::getControlPeriod() const {
    return controlPeriod;
}

double Model::getWarmTimeSteps() const {
    return warmTimeSteps;
}

// envrionement
const Environment& Model::getEnvironment() const {
    return environment;
}

void Model::setEnvironment(const Environment& environment) {
    this->environment = environment;
}

const Observations& Model::getObservations() const {
    return observations;
}

void Model::setObservations(const Observations& observations) {
    this->observations = observations;
}
