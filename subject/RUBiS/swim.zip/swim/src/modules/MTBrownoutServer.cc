/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include "Job.h"
#include "IPassiveQueue.h"
#include "SelectionStrategies.h"
#include "MTBrownoutServer.h"

Define_Module(MTBrownoutServer);

#define RNG 1
#define CACHING_EFFECT 0

using namespace std;

std::map<long, long> MTBrownoutServer::requestCount;

void MTBrownoutServer::initialize() {
    busySignal = registerSignal("busy");
    emit(busySignal, false);

    serviceTimeSignal = registerSignal("serviceTime");

    endExecutionMsg = new cMessage("end-execution");

    selectionStrategy = SelectionStrategy::create(par("fetchingAlgorithm"), this, true);
    if (!selectionStrategy)
        error("invalid selection strategy");

    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();
    maxThreads = par("threads");
    timeout = par("timeout").doubleValue();

    cacheLow = par("cacheLow");
    cacheRequestCount = par("cacheRequestCount");
    cacheDelta = par("cacheDelta");
    cacheDeltaLow = par("cacheDeltaLow");
    cachePrecision = par("cachePrecision");
    cacheClearsWhenReboot = par("cacheClearsWhenReboot");

    /*
    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [MTBrownoutServer] initialize debugging=" << debugging
                                  << " maxThreads="            << maxThreads
                                  << " timeout="               << timeout << endl;

        cout << "t=" << simTime() << " [MTBrownoutServer] initialize cacheLow=" << cacheLow
                                  << " cacheRequestCount="     << cacheRequestCount
                                  << " cacheDelta="            << cacheDelta
                                  << " cacheDeltaLow="         << cacheDeltaLow
                                  << " cachePrecision="        << cachePrecision
                                  << " cacheClearsWhenReboot=" << cacheClearsWhenReboot << endl;
    }*/
}

void MTBrownoutServer::handleMessage(cMessage* msg) {
    if (msg == endExecutionMsg) {
        ASSERT(!runningJobs.empty());
        updateJobTimes();

        // send out all jobs that completed
        RunningJobs::iterator first = runningJobs.begin();
        while (first != runningJobs.end() && first->remainingServiceTime < 1e-10) {

            // send it to serverMonitor
            send(first->pJob, "out");

            runningJobs.erase(first);
            first = runningJobs.begin();
        }

        if (!runningJobs.empty()) {
            scheduleNextCompletion();
        } else {
            emit(busySignal, false);
            if (hasGUI()) getDisplayString().setTagArg("i",1,"");
        }
    }
    else { // arrival jobs
        if (!isIdle())
            error("job arrived while already full");

        ScheduledJob job;
        job.pJob = check_and_cast<Job*>(msg);

        if (timeout > 0 && job.pJob->getTotalQueueingTime() >= timeout) {
            // don't serve this job, just send it out
            send(job.pJob, "out");
         } else {
            job.remainingServiceTime = generateJobServiceTime(job.pJob).dbl();

            // these two are nops if there was no job running
            updateJobTimes();
            cancelEvent(endExecutionMsg);

            runningJobs.push_back(job);
            runningJobs.sort();
            scheduleNextCompletion();

            if (runningJobs.size() == 1) { // going from idle to busy
                emit(busySignal, true);
                if (hasGUI()) getDisplayString().setTagArg("i",1,"cyan");
            }
        }
    }

    if (runningJobs.size() < maxThreads) {
        // examine all input queues, and request a new job from a non empty queue (multi-queues and multi-servers)
        int k = selectionStrategy->select();
        if (k >= 0) {
            cGate *gate = selectionStrategy->selectableGate(k);
            check_and_cast<IPassiveQueue *>(gate->getOwnerModule())->request(gate->getIndex());
        }
    }
}

void MTBrownoutServer::scheduleNextCompletion() {
    // schedule next completion event
    RunningJobs::iterator first = runningJobs.begin();
    scheduleAt(simTime() + first->remainingServiceTime*runningJobs.size(), endExecutionMsg);
}

void MTBrownoutServer::updateJobTimes() {
    simtime_t d = simTime() - endExecutionMsg->getSendingTime();

    // update service time and remaining time of all jobs
    for (RunningJobs::iterator it = runningJobs.begin(); it != runningJobs.end(); ++it) {
        it->remainingServiceTime -= d.dbl()/runningJobs.size(); // as if it was not sharing the processor
        it->pJob->setTotalServiceTime(it->pJob->getTotalServiceTime() + d);
    }
}

simtime_t MTBrownoutServer::generateJobServiceTime(queueing::Job* pJob) {
    double brownoutFactor = par("brownoutFactor");
    double u = uniform(0, 1, RNG);
    simtime_t st = 0;

    if (u >= brownoutFactor) {
        simtime_t serviceTime = par("serviceTime");
        if (serviceTime <= 0.0) {
            serviceTime = 1e-10; // make it a very short job
        }
        st = serviceTime;

    } else {
        pJob->setKind(1); // mark the job as low fidelity
        simtime_t serviceTime = par("lowFidelityServiceTime");
        if (serviceTime <= 0.0) {
            serviceTime = 1e-10; // make it a very short job
        }
        st = serviceTime;
    }

#if CACHING_EFFECT
    // exponential decay (simulate caching)
    if (cacheLow || pJob->getKind() != 1) {
        double delta = (pJob->getKind() == 1) ? cacheDeltaLow : cacheDelta;
        double lambda = (-1.0 / cacheRequestCount) * (log(cachePrecision * delta) - log(delta));

        long myRequestCount = requestCount[this->getParentModule()->getId()];
        st += delta * exp(-lambda * myRequestCount);
        requestCount[this->getParentModule()->getId()] = ++myRequestCount;
    }
#endif

    emit(serviceTimeSignal, (pJob->getKind() == 1) ? -st.dbl() : st.dbl());

    return st;
}

MTBrownoutServer::MTBrownoutServer() : endExecutionMsg(NULL), selectionStrategy(NULL), maxThreads(0) {
}

MTBrownoutServer::~MTBrownoutServer() {
    cancelAndDelete(endExecutionMsg);
    delete selectionStrategy;
    for (RunningJobs::iterator it = runningJobs.begin(); it != runningJobs.end(); ++it) {
        delete it->pJob;
    }
}

void MTBrownoutServer::clearServerCache() {
    if (cacheClearsWhenReboot) {
        requestCount[this->getParentModule()->getId()] = 0;
    }
}

bool MTBrownoutServer::isIdle() {
    return runningJobs.size() < maxThreads;
}

bool MTBrownoutServer::isEmpty() {
    return runningJobs.size() == 0;
}

void MTBrownoutServer::allocate() {
}
