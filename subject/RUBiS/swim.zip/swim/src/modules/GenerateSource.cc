/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <fstream>
#include "Job.h"
#include "GenerateSource.h"

Define_Module(GenerateSource);

using namespace std;

void GenerateSource::preload() {
    double arrivalTime = 0;

    const char* filePath = getSimulation()->getSystemModule()->par("interArrivalsFile");

    ifstream fin(filePath);
    if (!fin) {
        error("GenerateSource %s could not read input file '%s'", this->getFullName(), filePath);
    } else {
        double timeValue;
        while (fin >> timeValue) {
            timeValue *= scale;
            arrivalTime += timeValue;
            if (arrivalTime >= skip) {
                arrivalTimes.push_back(arrivalTime - skip);
                interArrivalTimes.push_back(timeValue);
            }
        }
        fin.close();

        cout << "t=" << simTime() << " [GenerateSource] read " << arrivalTimes.size() << " elements from " << filePath << " and arrivalTime is " << arrivalTime << "s" << endl;

        // set simulation limit time as arrivalTime (small time 20.0 for last step)
        getSimulation()->setSimulationTimeLimit(arrivalTime + 20.0);
    }
}

void GenerateSource::initialize() {
    SourceBase::initialize();

    scale = par("scale").doubleValue();
    skip = par("skip").doubleValue();

    nextArrivalIndex = 0;
    preload();

    // schedule the first message timer, if there is one
    if (interArrivalTimes.size() > 0) {
        scheduleAt(interArrivalTimes[nextArrivalIndex++], new cMessage("newJobTimer"));
    }
}

void GenerateSource::handleMessage(cMessage *msg) {

    if (nextArrivalIndex < interArrivalTimes.size()) {

        // reschedule the timer for the next message
        scheduleAt(simTime() + interArrivalTimes[nextArrivalIndex++], msg);

        // create arrival jobs and send it to arrivalMonitor
        queueing::Job *job = createJob();
        send(job, "out");

    } else {
        // finished
        delete msg;
    }
}

