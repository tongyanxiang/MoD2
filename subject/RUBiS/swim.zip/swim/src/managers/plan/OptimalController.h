//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __SWIM_PIC4DIM_H_
#define __SWIM_PIC4DIM_H_

#include <omnetpp.h>
#include <model/Model.h>
#include <managers/monitor/SimpleMonitor.h>
#include <managers/execution/ExecutionManagerMod.h>

using namespace omnetpp;

class OptimalController : public cSimpleModule
{
  public:
    int controlServers;

    void computeControlParamter();
    void setControlParamter();
    int getControlServers();

    Model *pModel;
    SimpleMonitor *pMonitor;
    ExecutionManagerModBase* pExecMgr;

  protected:
    // setpoint
    double setpoint = 0.3;

    // nominal model
    double beta = -0.076;

    // PI control parameter: pole
    double pole = 0.9;

    // control saturations and constraints
    int deltaSerMin = -1;
    int deltaSerMax = 1;
    int serMin = 1;
    int serMax = 10;

    int num = 0;

    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
