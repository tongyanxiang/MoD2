//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
#include <random>

#include "OptimalController.h"

Define_Module(OptimalController);

using namespace std;

void OptimalController::initialize() {
    pModel = check_and_cast<Model*> (getParentModule()->getSubmodule("model"));
    pMonitor = check_and_cast<SimpleMonitor*> (getParentModule()->getSubmodule("monitor"));
    pExecMgr = check_and_cast<ExecutionManagerModBase*> (getParentModule()->getSubmodule("executionManager"));

    controlServers = getSimulation()->getSystemModule()->par("initialServers");
    cout << "t=" << simTime() << " [OptimalController] controlServers=" << controlServers << endl;
}

void OptimalController::handleMessage(cMessage *msg) {
    computeControlParamter();
    setControlParamter();

    //finish
    delete msg;
}

void OptimalController::computeControlParamter() {

    double measuredAvgRespTime = pMonitor->getMeasuredAvgRespTime();

    // Compute new dimmer
    double K_p =  (1.0-pole)/beta;
    double err = setpoint-measuredAvgRespTime;

    int deltaSer = round(K_p*err);
    int saturatedDeltaSer = min(max(deltaSer, deltaSerMin), deltaSerMax);

    int saturatedNewSer = controlServers + saturatedDeltaSer;
    controlServers = min(max(saturatedNewSer,serMin),serMax);

    cout << "t=" << simTime() << " [OptimalController]"
                              << " measuredAvgRespTime[" << num << "]=" << measuredAvgRespTime
                              << " controlServers[" << num << "]="      << controlServers << endl;

    num = num + 1;
}

void OptimalController::setControlParamter() {

    // set servers
    if(controlServers > pModel->getServers()) {
        int additionalServers = controlServers - pModel->getServers();
        for(int i = 0; i < additionalServers; i++) {
            pExecMgr->addServer();
        }
    }

    if(controlServers < pModel->getServers()) {
        int removalServers = pModel->getServers() - controlServers;
        for(int i = 0; i < removalServers; i++) {
            pExecMgr->removeServer();
        }
    }
}

int OptimalController::getControlServers() {
    return controlServers;
}



