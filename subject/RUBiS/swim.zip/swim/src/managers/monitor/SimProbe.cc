/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <set>
#include <iostream>
#include <fstream>
#include "managers/execution/ExecutionManagerModBase.h"
#include "SimProbe.h"

using namespace std;
using namespace omnetpp;

Define_Module(SimProbe);

void SimProbe::initialize(int stage) {
    if (stage == 1) {
        cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

        /* register arrivalMonitor signals */
        interArrivalSignal = registerSignal("interArrival");
        getSimulation()->getSystemModule()->subscribe(interArrivalSignal, this);

        /* register server signals */
        serviceTimeSignal = registerSignal("serviceTime");
        getSimulation()->getSystemModule()->subscribe(serviceTimeSignal, this);

        /* register sinkMonitor signals */
        lifeTimeSignal = registerSignal("lifeTime");
        getSimulation()->getSystemModule()->subscribe(lifeTimeSignal, this);

        /* subscribed server state signals */
        serverBusySignal = registerSignal("busy");
        getSimulation()->getSystemModule()->subscribe(serverBusySignal, this);

        serverRemovedSignal = registerSignal(ExecutionManagerModBase::SIG_SERVER_REMOVED);
        getSimulation()->getSystemModule()->subscribe(serverRemovedSignal, this);

        /* subscribed runningJobSize: from request in to out */
        runningJobsSizeSignal = registerSignal("runningJobsSize");
        getSimulation()->getSystemModule()->subscribe(runningJobsSizeSignal, this);

        cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging");
        pModel = check_and_cast<Model*>(getParentModule()->getSubmodule("model"));
        window = pModel->getControlPeriod();

        arrival.setWindow(window);
        basicServiceTime.setWindow(window);
        optServiceTime.setWindow(window);;
        basicResponseTime.setWindow(window);
        optResponseTime.setWindow(window);
        responseTime.setWindow(window);
        runningJobsSize.setWindow(window);
    }
}

void SimProbe::receiveSignal(cComponent *source, simsignal_t signalID, const SimTime& t, cObject *details) {
    if (signalID == lifeTimeSignal) {
        responseTime.record(t.dbl()); //windows for saving all basic and opt responseTime
        bool basic = (strcmp(source->getName(), "sinkLow") == 0);
        if (basic) {
            basicResponseTime.record(t.dbl());
        } else {
            optResponseTime.record(t.dbl());
       }
       servedJobs++ ;
       double runningJobsSizePerServer = (enteredJobs-servedJobs)/pModel->getActiveServers();
       runningJobsSize.record(runningJobsSizePerServer);
    }
}

void SimProbe::receiveSignal(cComponent *source, simsignal_t signalID, double value, cObject *details) {
    if (signalID == interArrivalSignal) {
        arrival.record(value);
        enteredJobs++ ;
    } else if (signalID == serviceTimeSignal){
        if (value <= 0.0) {
            basicServiceTime.record(value);
        } else {
            optServiceTime.record(value);
        }
    }
}

void SimProbe::receiveSignal(cComponent *source, simsignal_t signalID, bool value, cObject *details) {
    if (signalID == serverBusySignal) {
        std::string serverName = source->getParentModule()->getName(); // because it is nested

        auto it = utilization.find(serverName);
        if (it != utilization.end()) {
            it->second.record((value) ? 1.0 : 0.0); // busy vs idle
        } else {
            /*
             * a new server emits a busy=false signal when it is initialized.
             * It should not be recorded for a new server because it then
             * throws off the sliding window avg utilization computation
             */
            if (value) {
                auto& util = utilization[serverName];
                util.setWindow(window);
                util.record(1.0); // busy
            }
        }
    }
}

void SimProbe::receiveSignal(cComponent *source, simsignal_t signalID, const char* value, cObject *details) {
    if (signalID == serverRemovedSignal) {
        auto it = utilization.find(value);
        if (it != utilization.end()) {
            utilization.erase(it);
        }
    }
}

double SimProbe::getUtilization(const std::string& serverName) {
    auto it = utilization.find(serverName);
    if (it != utilization.end()) {
        return it->second.getPercentageAboveZero();
    }

    return -1.0; // error: server not found
}

void SimProbe::handleMessage(cMessage *msg) {
}

Observations SimProbe::getUpdatedObservations() {
    Observations obs;

    obs.basicResponseTime = basicResponseTime.getAverage();
    obs.basicThroughput = basicResponseTime.getRate();
    obs.optResponseTime = optResponseTime.getAverage();
    obs.optThroughput = optResponseTime.getRate();
    obs.avgResponseTime = (obs.basicResponseTime*obs.basicThroughput + obs.optResponseTime*obs.optThroughput)/(obs.basicThroughput + obs.optThroughput);

    double util = 0;
    for (auto& entry : utilization) {
        util += entry.second.getPercentageAboveZero();
    }
    obs.utilization = util/pModel->getActiveServers();

    obs.avgRunningJobsSize = runningJobsSize.getAverage();
    obs.runningJobsThroughput = runningJobsSize.getRate();

    return obs;
}

Environment SimProbe::getUpdatedEnvironment() {
    double arrivalRate = arrival.getRate();
    double measuredMeanInterArrival = (arrivalRate > 0) ? (1.0/arrivalRate) : 0.0;

    Environment environment;
    environment.setArrivalRate(arrivalRate);
    environment.setArrivalMean(measuredMeanInterArrival);
    environment.setArrivalVariance(pow(measuredMeanInterArrival, 2)); // assume exponential distribution

    /*
    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [SimProbe] getUpdatedEnvironment setArrivalRate=" << arrivalRate
                                  << " setArrivalMean=" << measuredMeanInterArrival
                                  << " setArrivalVariance=" << pow(measuredMeanInterArrival, 2) << endl;
    }*/

    return environment;
}
