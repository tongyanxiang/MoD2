/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/
#include <cmath>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include "managers/ModulePriorities.h"
#include "SimpleMonitor.h"

Define_Module(SimpleMonitor);

#define RNG 3

using namespace omnetpp;

SimpleMonitor::SimpleMonitor() {
    periodEvent = 0;
}

void SimpleMonitor::initialize(int stage) {
    if (stage == 1) {

        pModel = check_and_cast<Model*>(getParentModule()->getSubmodule("model"));
        double controlPeriod = pModel->getControlPeriod();
        int warmTimeSteps = pModel->getWarmTimeSteps();

        simulationWarmTime = controlPeriod*(double)warmTimeSteps;
        cout << "t=" << simTime() << " [SimpleMonitor] initialize simulationWarmTime=" << simulationWarmTime << endl;

        pSimProbe = check_and_cast<SimProbe*>(getParentModule()->getSubmodule("simProbe"));

        oversamplingFactor = par("oversamplingFactor");

        // Create the event objects we'll use for timing -- just any ordinary message.
        periodEvent = new cMessage("periodEvent");
        periodEvent->setSchedulingPriority(MONITOR_PRE_PRIO);
        scheduleAt(pModel->getControlPeriod(), periodEvent);

        oversamplingEvent = new cMessage("oversamplingEvent");
        oversamplingEvent->setSchedulingPriority(MONITOR_PRE_OVERSAMPLING_PRIO);
        scheduleAt(computeNextEventTime(oversamplingFactor), oversamplingEvent);
    }
}

/**
 * Computes the time for the next oversampling event
 */
simtime_t SimpleMonitor::computeNextEventTime(unsigned factor) const {
    simtime_t t = simTime() + pModel->getControlPeriod()/factor;

    // if it's close to the evaluation period, make it equal so that they don't get out of sync
    if (abs((t - periodEvent->getArrivalTime()).dbl()) < 0.01) {
        t = periodEvent->getArrivalTime();
    }

    return t;
}

void SimpleMonitor::handleMessage(cMessage *msg) {
    /*
     * the monitoring is divided into three parts. One handles events at rates faster than
     * the evaluation period.
     * Then, one that executes before the adaptation manager
     * and the other that executes after, so that statistics signals can reflect what the
     * adaptation manager just did (like adding a server)
     */
    if (msg == oversamplingEvent) {
        oversamplingHandler();
        scheduleAt(computeNextEventTime(oversamplingFactor), oversamplingEvent);

    } else if (msg == periodEvent) {
        periodicHandler();
        scheduleAt(simTime() + pModel->getControlPeriod(), periodEvent);

        if (simTime() > simulationWarmTime) {
            // measurements
            measuredArrivalRate = pModel->getEnvironment().getArrivalRate();

            double sensorNoise = normal(0.0, 0.001, RNG);
            while(pModel->getObservations().avgResponseTime + sensorNoise<0.0){
                sensorNoise = normal(0.0, 0.001, RNG);
            }
            measuredAvgRespTime = pModel->getObservations().avgResponseTime + sensorNoise;

            // message
            cMessage *controlEvent = new cMessage("controlEvent");
            send(controlEvent, "out");
        }
    }
}

void SimpleMonitor::periodicHandler() {
    Observations observations = pSimProbe->getUpdatedObservations();
    pModel->setObservations(observations);
}

void SimpleMonitor::oversamplingHandler() {
    Environment environment = pSimProbe->getUpdatedEnvironment();
    pModel->setEnvironment(environment);
}

SimpleMonitor::~SimpleMonitor() {
    cancelAndDelete(periodEvent);
    cancelAndDelete(oversamplingEvent);
}

double SimpleMonitor::getMeasuredArrivalRate() {
    return measuredArrivalRate;
}

double SimpleMonitor::getMeasuredAvgRespTime() {
    return measuredAvgRespTime;
}



