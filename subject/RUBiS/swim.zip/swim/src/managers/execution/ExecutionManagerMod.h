/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/
#ifndef EXECUTIONMANAGERMOD_H_
#define EXECUTIONMANAGERMOD_H_

#include <set>
#include <omnetpp.h>
#include "model/Model.h"
#include "BootComplete_m.h"
#include "ExecutionManagerModBase.h"

class ExecutionManagerMod : public ExecutionManagerModBase, omnetpp::cListener {
    omnetpp::simsignal_t serverBusySignalId;

    std::vector<int> serverModuleIds;
    std::vector<int> serverBeingRemovedModuleIds;

    /**
     * Sends a message so that when received (immediately) will complete the removal
     * This is used so that the signal handler can do it
     */
    void completeServerRemoval(int moduleId);

    bool isServerBeingRemoveEmpty(int moduleId);

  protected:
    virtual void initialize();
    virtual void handleMessage(omnetpp::cMessage *msg);

    /**
     * @return BootComplete* to be handled later by doAddServerBootComplete()
     */
    virtual BootComplete* doAddServer(bool instantaneous = false);
    virtual void doAddServerBootComplete(BootComplete* bootComplete);

    /**
     * @return BootComplete* identical in content (not the pointer itself) to
     *   what doAddServer() would have return for this server
     */
    virtual void doRemoveServer(BootComplete* bootComplete);

    virtual void doSetBrownout(double factor);

  public:
    virtual void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, bool value, cObject *details) override;
};

#endif /* EXECUTIONMANAGERMOD_H_ */
