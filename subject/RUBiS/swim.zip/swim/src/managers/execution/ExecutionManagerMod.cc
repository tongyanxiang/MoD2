/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <sstream>
#include <cstdlib>
#include <boost/tokenizer.hpp>
#include "PassiveQueue.h"
#include "util/Utils.h"
#include "modules/MTBrownoutServer.h"
#include "ExecutionManagerMod.h"

using namespace std;
using namespace omnetpp;

Define_Module(ExecutionManagerMod);

const char* LOAD_BALANCER_MODULE_NAME = "loadBalancer";
const char* SERVER_MODULE_NAME = "server";
const char* INTERNAL_QUEUE_MODULE_NAME = "queue";
const char* INTERNAL_SERVER_MODULE_NAME = "server";
const char* CLASSIFIER_MODULE_NAME = "classifier";

void ExecutionManagerMod::initialize() {
    ExecutionManagerModBase::initialize();

    serverBusySignalId = registerSignal("busy");
    getSimulation()->getSystemModule()->subscribe(serverBusySignalId, this);
}

void ExecutionManagerMod::handleMessage(cMessage *msg) {

    BootComplete* bootComplete = check_and_cast<BootComplete*>(msg);

    if (strcmp(bootComplete->getExpectedChange(),"removeServerDelay") == 0) {
        doRemoveServer(bootComplete);

    } else if (strcmp(bootComplete->getExpectedChange(),"removeServer") == 0) {

        cModule* module = getSimulation()->getModule(bootComplete->getModuleId());

        stringstream serverId;
        serverId << module->getId();

        // remove from model
        notifyRemoveServerCompleted(serverId.str().c_str());

        if(cmdenvLogging) {
            std::cout << "t=" << simTime() << " [ExecutionManagerModBase] reomveServer(id=" << bootComplete->getModuleId() << ") complete" << endl;
        }

        // disconnect gates and delete module
        module->gate("out")->disconnect();
        module->deleteModule();
        cancelAndDelete(msg);

    } else if (strcmp(bootComplete->getExpectedChange(),"addServer") == 0) {
        ExecutionManagerModBase::handleMessage(bootComplete);
    }
}

void ExecutionManagerMod::doSetBrownout(double factor) {
    serverModuleIds = pModel->getServerPool();
    for(unsigned int i=0; i<serverModuleIds.size(); i++) {
        cModule* module = getSimulation()->getModule(serverModuleIds[i]);
        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ExecutionManagerMod] doSetBrownout serverModuleIds[" << i << "]=" << serverModuleIds[i]
                                      << " moduleName="<< module->getName()
                                      << " factor="<< factor << endl;
        }
        module->getSubmodule("server")->par("brownoutFactor").setDoubleValue(factor);
    }
}

void ExecutionManagerMod::doAddServerBootComplete(BootComplete* bootComplete) {

    cModule *server = getSimulation()->getModule(bootComplete->getModuleId());
    cModule *loadBalancer = getParentModule()->getSubmodule(LOAD_BALANCER_MODULE_NAME);
    cModule *classifier = getParentModule()->getSubmodule(CLASSIFIER_MODULE_NAME);

    // update booted server name
    int activeServerCount = pModel->getActiveServers();
    stringstream name;
    name << SERVER_MODULE_NAME;
    name << activeServerCount + 1;
    server->setName(name.str().c_str());

    // connect gates
    loadBalancer->getOrCreateFirstUnconnectedGate("out", 0, false, true)->connectTo(server->gate("in"));
    server->gate("out")->connectTo(classifier->getOrCreateFirstUnconnectedGate("in", 0, false, true));

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ExecutionManagerMod] executing doAddServerBootComplete(id=" << bootComplete->getModuleId()
                                  << "): update booted server name=" << server->getName() << " and connect gates"<< endl;
    }
}

BootComplete* ExecutionManagerMod::doAddServer(bool instantaneous) {

    // find factory object
    cModuleType *moduleType = cModuleType::get("coada.modules.AppServer");
    int serverCount = pModel->getServers();
    stringstream name;
    name << SERVER_MODULE_NAME;
    name << serverCount + 1;
    cModule *module = moduleType->create(name.str().c_str(), getParentModule());

    // setup parameters
    module->finalizeParameters();
    module->buildInside();

    // copy all params of the server inside the appserver module from the template
    cModule* pNewSubmodule = module->getSubmodule(INTERNAL_SERVER_MODULE_NAME);
    if (serverCount > 1) {
        // copy from an existing server
        stringstream templateName;
        templateName << SERVER_MODULE_NAME;
        templateName << 1;
        cModule* pTemplateSubmodule = getParentModule()->getSubmodule(templateName.str().c_str())->getSubmodule(INTERNAL_SERVER_MODULE_NAME);

        for (int i = 0; i < pTemplateSubmodule->getNumParams(); i++) {
            pNewSubmodule->par(i) = pTemplateSubmodule->par(i);
        }
    } else {
        // if it's the first server, we need to set the parameters common to all servers in the model
        pModel->setServerThreads(pNewSubmodule->par("threads"));
        double variance = 0.0;
        double mean = Utils::getMeanAndVarianceFromParameter(pNewSubmodule->par("serviceTime"), &variance);
        pModel->setServiceTime(mean, variance);
        mean = Utils::getMeanAndVarianceFromParameter(pNewSubmodule->par("lowFidelityServiceTime"), &variance);
        pModel->setLowFidelityServiceTime(mean, variance);
    }

    // create activation message
    module->scheduleStart(simTime());
    module->callInitialize();

    if(cmdenvLogging) {
        cout << "t=" << simTime()<< " [ExecutionManagerMod] executing doAddServer(id="<< module->getId() << ")" << endl;
    }

    BootComplete* bootComplete = new BootComplete;
    bootComplete->setModuleId(module->getId());
    bootComplete->setExpectedChange("addServer");

    return bootComplete;
}

void ExecutionManagerMod::doRemoveServer(BootComplete* bootComplete) {

    int moduleId = bootComplete->getModuleId();

    // disconnect module
    cModule *module = getSimulation()->getModule(moduleId);
    cGate* pInGate = module->gate("in");
    if (pInGate->isConnected()) {
        cGate *otherEnd = pInGate->getPathStartGate();
        otherEnd->disconnect();
        ASSERT(otherEnd->getIndex() == otherEnd->getVectorSize()-1);

        // reduce the size of the out gate in the queue module
        otherEnd->getOwnerModule()->setGateSize(otherEnd->getName(), otherEnd->getVectorSize()-1);
        // this is probably leaking memory because the gate may not be being deleted
    }

    if(cmdenvLogging) {
         std::cout << "t=" << simTime() << " [ExecutionManagerMod] doRemoveServer(id=" << moduleId << "): moduleName=" << module->getName() << endl;
    }

    // check to see if we can delete the server immediately (or if it's busy)
    if (isServerBeingRemoveEmpty(moduleId)) {
        completeServerRemoval(moduleId);
    } else {
        serverBeingRemovedModuleIds.push_back(moduleId);
    }
}

void ExecutionManagerMod::completeServerRemoval(int moduleId) {
    Enter_Method("sendMe()");

    // clear cache for server, so that the next time it is instantiated it is fresh
    cModule* module = getSimulation()->getModule(moduleId);
    check_and_cast<MTBrownoutServer*>(module->getSubmodule(INTERNAL_SERVER_MODULE_NAME))->clearServerCache();

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ExecutionManagerMod] completeServerRemoval(id="<< moduleId <<"): clearServerCache" << endl;
    }

    BootComplete* pBootComplete = new BootComplete;
    pBootComplete->setModuleId(moduleId);
    pBootComplete->setExpectedChange("removeServer");

    scheduleAt(simTime(), pBootComplete);
}

bool ExecutionManagerMod::isServerBeingRemoveEmpty(int moduleId) {
    bool isEmpty = false;
    cModule* module = getSimulation()->getModule(moduleId);
    MTBrownoutServer* internalServer = check_and_cast<MTBrownoutServer*> (module->getSubmodule(INTERNAL_SERVER_MODULE_NAME));
    if (internalServer->isEmpty()) {
        queueing::PassiveQueue* queue = check_and_cast<queueing::PassiveQueue*> (module->getSubmodule(INTERNAL_QUEUE_MODULE_NAME));
        if (queue->length() == 0) {
            isEmpty = true;
        }
    }

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ExecutionManagerMod] isServerBeingRemoveEmpty=" << isEmpty << endl;
    }

    return isEmpty;
}

void ExecutionManagerMod::receiveSignal(cComponent *source, simsignal_t signalID, bool value, cObject *details) {
    if (signalID == serverBusySignalId && value == false) {
        std::vector<int>::iterator it = std::find(serverBeingRemovedModuleIds.begin(), serverBeingRemovedModuleIds.end(), source->getParentModule()->getId());

        if (it != serverBeingRemovedModuleIds.end()) {

            int serverBeingRemovedModuleId = it[0];
            serverBeingRemovedModuleIds.erase(it);

            if(cmdenvLogging) {
                cout << "t=" << simTime() << " [ExecutionManagerMod] serverBeingRemovedModuleId=" << serverBeingRemovedModuleId << endl;
            }

            if (isServerBeingRemoveEmpty(serverBeingRemovedModuleId)) {
                completeServerRemoval(serverBeingRemovedModuleId);
            }
        }
    }
}




