/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/
#ifndef EXECUTIONMANAGERMODBASE_H_
#define EXECUTIONMANAGERMODBASE_H_

#include <set>
#include <omnetpp.h>
#include "model/Model.h"
#include "BootComplete_m.h"
#include "ExecutionManager.h"

class ExecutionManagerModBase : public omnetpp::cSimpleModule, public ExecutionManager {

    omnetpp::simsignal_t serverRemovedSignal;

  protected:
    bool cmdenvLogging;
    Model* pModel;

    virtual void initialize();
    virtual void handleMessage(omnetpp::cMessage *msg);

    virtual void doSetBrownout(double factor) = 0;

    /**
     * When a remove server completes, the implementation must call this function
     *
     * This is used to, for example, wait for a server to complete ongoing requests
     * doRemoveServer() can disconnect the server from the load balancer
     * and when all requests in the server have been processed, call this method,
     * so that the server is removed from the model
     * TODO there should be a state in the model to mark servers being shutdown
     */
    void notifyRemoveServerCompleted(const char* serverId);

    /**
     * @return BootComplete* to be handled later by doAddServerBootComplete()
     */
    virtual BootComplete* doAddServer(bool instantaneous = false) = 0;
    virtual void doAddServerBootComplete(BootComplete* bootComplete) = 0;

    /**
     * @return BootComplete* identical in content (not the pointer itself) to
     *   what doAddServer() would have returned for this server
     */
    virtual void doRemoveServer(BootComplete* bootComplete) = 0;

  public:
    static const char* SIG_SERVER_REMOVED;

    virtual void addServerLatencyOptional(bool instantaneous = false);
    virtual void removeServerLatencyOptional(bool instantaneous = false);

    // ExecutionManager interface
    virtual void setBrownout(double factor);
    virtual void addServer();
    virtual void removeServer();

};

#endif /* EXECUTIONMANAGERMODBASE_H_ */

/* add server process
 * -new or copy a server module and new bootComplete
 * -add server change to model (addExpectedServerChange and pushServerPool)
 * -wait bootDelay
 * -update server name and connect server
 * -notify add complete to model (serverBecameActive)
 */

/* remove server process
 * -disconnect from load balancer
 * -mark as to be removed
 * -wait until empty: busy=0 signal from server && queue empty && marked to be removed
 * -remove from model
 * -delete module
 */
