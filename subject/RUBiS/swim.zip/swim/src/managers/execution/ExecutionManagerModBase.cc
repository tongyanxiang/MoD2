/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/
#include <sstream>
#include <cstdlib>
#include "ExecutionManagerModBase.h"

using namespace std;
using namespace omnetpp;

const char* ExecutionManagerModBase::SIG_SERVER_REMOVED = "serverRemoved";

void ExecutionManagerModBase::initialize() {
    serverRemovedSignal = registerSignal(SIG_SERVER_REMOVED);

    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging");
    pModel = check_and_cast<Model*> (getParentModule()->getSubmodule("model"));
}

void ExecutionManagerModBase::handleMessage(cMessage* msg) {

    BootComplete* bootComplete = check_and_cast<BootComplete*>(msg);

    // update server name and connect server to loadBalancer, classifier
    doAddServerBootComplete(bootComplete);

    // notify add complete to model
    pModel->serverBecameActive();

    if(cmdenvLogging) {
        std::cout << "t=" << simTime() << " [ExecutionManagerModBase] addServer(id=" << bootComplete->getModuleId() << ") complete" << endl;
    }

    delete bootComplete;
}

void ExecutionManagerModBase::setBrownout(double factor) {
    Enter_Method("setBrownout()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ExecutionManagerModBase] executing setBrownout factor=" << factor << endl;
    }

    pModel->setBrownoutFactor(factor);
    doSetBrownout(factor);
}

void ExecutionManagerModBase::addServer() {
    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ExecutionManagerModBase] executing addServer()" << endl;
    }

    addServerLatencyOptional();
}

void ExecutionManagerModBase::addServerLatencyOptional(bool instantaneous) {
    Enter_Method("addServer()");

    // new or copy a server module and new bootComplete
    BootComplete* bootComplete = doAddServer(instantaneous);

    double bootDelay = 0;
    if (!instantaneous) {
        bootDelay = getSimulation()->getSystemModule()->par("bootDelay").doubleValue();

        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ExecutionManagerModBase] adding server(id="<< bootComplete->getModuleId() <<") with latency=" << bootDelay << endl;
        }
    }

    // add expected SERVER_ONLINE changes
    pModel->addServer(bootDelay);

    // push to server pool
    pModel->pushServerPool(simTime().dbl() + bootDelay, bootComplete->getModuleId());

    if (bootDelay == 0) {
        handleMessage(bootComplete);
    } else {
        scheduleAt(simTime() + bootDelay, bootComplete);
    }
}

void ExecutionManagerModBase::removeServer() {
    Enter_Method("removeServer()");

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ExecutionManagerModBase] executing removeServer()" << endl;
    }

    removeServerLatencyOptional();
}

void ExecutionManagerModBase::removeServerLatencyOptional(bool instantaneous) {
    Enter_Method("removeServer()");

    int moduleId = pModel->popServerPool();

    BootComplete* bootComplete = new BootComplete;
    bootComplete->setModuleId(moduleId);
    bootComplete->setExpectedChange("removeServerDelay");

    double offDelay = 0;
    if (!instantaneous) {
        offDelay = getSimulation()->getSystemModule()->par("offDelay").doubleValue();

        if(cmdenvLogging) {
            cout << "t=" << simTime() << " [ExecutionManagerModBase] removing server(id="<< bootComplete->getModuleId() <<") with latency=" << offDelay << endl;
        }
    }

    // add expected SERVER_OFFLINE changes
    pModel->removeServer(offDelay);

    if (offDelay == 0) {
        handleMessage(bootComplete);
    } else {
        scheduleAt(simTime() + offDelay, bootComplete);
    }
}

void ExecutionManagerModBase::notifyRemoveServerCompleted(const char* serverId) {
    // update model for notify remove server completed
    pModel->serverBecameShutDown();

    // emit signal to notify others (notably simProbe)
    emit(serverRemovedSignal, serverId);
}
